﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.DTOs
{
    public class MovieDto
    {
        public int Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public DateOnly? ReleaseDate { get; set; }
        public int? Duration { get; set; }
        public string GenreNames { get; set; } = string.Empty;
        public int SessionsCount { get; set; }
    }

    public class MovieFormDto
    {
        public int Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public string? Description { get; set; }
        public DateOnly? ReleaseDate { get; set; }
        public int? Duration { get; set; }
        public string? PosterPath { get; set; }
        public string? BackdropPath { get; set; }
        public string? OriginalName { get; set; }
        public string? Language { get; set; }
        public string? TrailerUrl { get; set; }
        public List<int> GenreIds { get; set; } = new();
        public List<int> ActorIds { get; set; } = new();
        public List<string> CountryCodes { get; set; } = new();
        public List<int> DirectorIds { get; set; } = new();

    }
}
